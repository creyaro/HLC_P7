import { Component } from '@angular/core';
import { StudentsService } from '../students.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; // necesario para el two way binding

@Component({
selector: 'app-student-create',
standalone: true,
imports: [CommonModule, FormsModule],
templateUrl: './student-create.component.html',
styleUrl: './student-create.component.css'
})

export class StudentCreateComponent {

constructor(private readonly studentsService: StudentsService) {}

  student = {
    name: '',
    dni: '',
    birthDate: ''
  };

  httpMessagge = {
    texto: string = "";
    requestSuccess: boolean= false;
    error: string = "";
    requestFailed: boolean = false;
};

  onSubmit() {
    this.studentsService.createStudent(this.student).subscribe(res => {
      // Show success msg
    this.requestSuccess= true;
    this.showError(res);
},
err => {
    this.requestFailed = true;
    this.showError(err);
});
}
showError(res: any) {
    this.message;
}
}
